extends Control

const HDTheme := preload("res://scripts/ui/HDTheme.gd")
const ChartLoader := preload("res://scripts/gameplay/ChartLoader.gd")
const ChartValidator := preload("res://scripts/songs/ChartValidator.gd")
const AudioResolver := preload("res://scripts/songs/AudioResolver.gd")
const SongResolver := preload("res://scripts/songs/SongResolver.gd")

const GridSnapManager := preload("res://scripts/editor/GridSnapManager.gd")
const PlaybackController := preload("res://scripts/editor/PlaybackController.gd")
const WaveformRenderer := preload("res://scripts/editor/WaveformRenderer.gd")
const NotePlacementSystem := preload("res://scripts/editor/NotePlacementSystem.gd")
const SongDatabase := preload("res://scripts/songs/SongDatabase.gd")
const EditorLog := preload("res://scripts/editor/EditorLog.gd")
const BPMDetector := preload("res://scripts/editor/BPMDetector.gd")

const ANALYSIS_BUS_NAME := &"ChartEditorAnalysis"
const DEFAULT_PX_PER_SECOND := 140.0
const PLAYBACK_TARGET_OFFSET_RATIO := 0.35
const MANUAL_REVEAL_CENTER_RATIO := 0.50
const SCROLL_UPDATE_THRESHOLD_PX := 0.5

@onready var _top_panel: PanelContainer = %TopPanel
@onready var _status_label: Label = %StatusLabel
@onready var _reload_songs_button: Button = %ReloadSongsButton
@onready var _song_option: OptionButton = %SongOption
@onready var _difficulty_option: OptionButton = %DifficultyOption
@onready var _snap_option: OptionButton = %SnapOption
@onready var _play_button: Button = %PlayButton
@onready var _save_button: Button = %SaveButton
@onready var _audio_option: OptionButton = %AudioOption
@onready var _browse_audio_button: Button = %BrowseAudioButton
@onready var _bpm_spin: SpinBox = %BPMSpin
@onready var _auto_bpm_button: Button = %AutoBPMButton
@onready var _scroll: ScrollContainer = %TimelineScroll
@onready var _timeline: TimelineView = %TimelineView
@onready var _audio_player: AudioStreamPlayer = %AudioPlayer
@onready var _audio_file_dialog: FileDialog = %AudioFileDialog

var _grid := GridSnapManager.new()
var _playback := PlaybackController.new()
var _waveform := WaveformRenderer.new()
var _notes := NotePlacementSystem.new()
var _song_db := SongDatabase.new()

var _song_folder := ""
var _difficulty := "expert"
var _chart_path := ""
var _manifest_path := ""

var _px_per_second := DEFAULT_PX_PER_SECOND
var _chart_load_error := ""
var _song_entries: Array[Dictionary] = []
var _selected_song_id := ""
var _is_switching_song := false
var _audio_reason := ""
var _selected_audio_path := ""
var _analysis_bus_idx := -1
var _analysis_capture: AudioEffectCapture
var _analysis_in_progress := false


func _ready() -> void:
	SongResolver.ensure_user_song_dirs()
	EditorLog.info("boot", "ChartEditorScene ready")
	_ensure_analysis_bus()

	_apply_style()
	_setup_snap_options()
	_setup_song_picker()

	_playback.attach_player(_audio_player)
	_notes.attach_grid(_grid)

	_timeline.attach(_grid, _waveform)
	_apply_default_zoom()
	_timeline.time_clicked.connect(_on_time_clicked)
	_timeline.scrub_requested.connect(_on_scrub_requested)
	_timeline.zoom_requested.connect(_on_zoom_requested)

	_scroll.get_h_scroll_bar().value_changed.connect(func(v: float) -> void:
		_timeline.set_scroll_x(v)
	)

	_playback.position_changed.connect(func(t: float) -> void:
		_timeline.set_cursor_time(t)
		_reveal_time(t, _playback.is_playing())
		_update_status()
	)
	_playback.play_state_changed.connect(func(is_playing: bool) -> void:
		_play_button.text = "Pause" if is_playing else "Play"
		if is_playing:
			_reveal_time(_playback.get_position(), true)
		EditorLog.info("playback", "state=%s" % ("playing" if is_playing else "paused"))
	)
	_playback.audio_loaded.connect(func(has_audio: bool, length_sec: float) -> void:
		_timeline.set_audio_length(length_sec)
		EditorLog.info("audio", "loaded=%s length=%.3f" % [str(has_audio), length_sec])
	)

	_notes.notes_changed.connect(func() -> void:
		_timeline.set_notes(_notes.get_notes())
		EditorLog.info("notes", "count=%d" % _notes.get_notes().size())
		_update_status()
	)

	_play_button.pressed.connect(func() -> void:
		EditorLog.info("ui", "Play button pressed")
		_playback.toggle_play()
	)
	_browse_audio_button.pressed.connect(func() -> void:
		EditorLog.info("ui", "Browse audio pressed")
		_audio_file_dialog.popup_centered_ratio(0.7)
	)
	_audio_file_dialog.file_selected.connect(func(path: String) -> void:
		_on_audio_file_selected(path)
	)
	_audio_option.item_selected.connect(func(_idx: int) -> void:
		_on_audio_option_selected()
	)
	_bpm_spin.value_changed.connect(_on_bpm_spin_changed)
	_auto_bpm_button.pressed.connect(_on_auto_bpm_pressed)
	_save_button.pressed.connect(_on_save_pressed)

	_read_cmdline()
	_reload_songs()
	_load_session()
	_update_status()


func _process(delta: float) -> void:
	_playback.process_update()


func _apply_default_zoom() -> void:
	_px_per_second = DEFAULT_PX_PER_SECOND
	_timeline.set_zoom(_px_per_second)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and (event as InputEventKey).pressed and not (event as InputEventKey).echo:
		var k: InputEventKey = event as InputEventKey
		if k.keycode == KEY_SPACE:
			EditorLog.info("input", "Space play/pause")
			_playback.toggle_play()
			accept_event()
			return
		if k.keycode == KEY_S and k.ctrl_pressed:
			EditorLog.info("input", "Ctrl+S save")
			save_chart()
			accept_event()
			return
		if k.keycode == KEY_LEFT:
			EditorLog.info("input", "Scrub left")
			var prev_time := _grid.prev_step_time(_playback.get_position())
			_playback.seek(prev_time)
			_reveal_time(prev_time, _playback.is_playing())
			accept_event()
			return
		if k.keycode == KEY_RIGHT:
			EditorLog.info("input", "Scrub right")
			var next_time := _grid.next_step_time(_playback.get_position())
			_playback.seek(next_time)
			_reveal_time(next_time, _playback.is_playing())
			accept_event()
			return
		if k.keycode == KEY_H:
			_notes.hold_mode = not _notes.hold_mode
			EditorLog.info("input", "HoldMode=%s" % str(_notes.hold_mode))
			_update_status()
			accept_event()
			return

		var lane := _lane_for_key(k.keycode)
		if lane >= 0:
			EditorLog.info("input", "Place note via key lane=%d shift=%s" % [lane, str(k.shift_pressed)])
			_notes.handle_keyboard_lane(_playback.get_position(), lane, k.shift_pressed)
			accept_event()


func _lane_for_key(keycode: int) -> int:
	match keycode:
		KEY_1: return 0
		KEY_2: return 1
		KEY_3: return 2
		KEY_4: return 3
		KEY_5: return 4
		_:
			return -1


func _on_bpm_spin_changed(v: float) -> void:
	_grid.bpm = v
	EditorLog.info("grid", "bpm override=%.3f" % _grid.bpm)
	_update_status()


func _on_auto_bpm_pressed() -> void:
	_auto_detect_bpm()


func _on_save_pressed() -> void:
	save_chart()


func _on_time_clicked(time_sec: float, lane: int, button_index: int, shift: bool) -> void:
	var snapped := _grid.snap_time(time_sec)
	_playback.seek(snapped)
	_reveal_time(snapped, _playback.is_playing())
	EditorLog.info("mouse", "click button=%d lane=%d t=%.3f snapped=%.3f shift=%s" % [button_index, lane, time_sec, snapped, str(shift)])

	var tolerance := maxf(0.008, 7.0 / _px_per_second)
	if button_index == MOUSE_BUTTON_RIGHT:
		_notes.delete_nearest(snapped, lane, tolerance)
	else:
		if shift or _notes.hold_mode:
			_notes.handle_keyboard_lane(snapped, lane, true)
		else:
			_notes.place_tap(snapped, lane)


func _on_scrub_requested(time_sec: float) -> void:
	var snapped := _grid.snap_time(time_sec)
	EditorLog.info("mouse", "scrub t=%.3f snapped=%.3f" % [time_sec, snapped])
	_playback.seek(snapped)
	_reveal_time(snapped, _playback.is_playing())


func _on_zoom_requested(multiplier: float, _at_local_x: float) -> void:
	var before := _px_per_second
	var cursor_time := _playback.get_position()
	var playhead_screen_x := cursor_time * before - _scroll.scroll_horizontal
	_px_per_second = clampf(_px_per_second * multiplier, 40.0, 1200.0)
	EditorLog.info("mouse", "zoom multiplier=%.3f px_per_sec=%.1f" % [multiplier, _px_per_second])
	_timeline.set_zoom(_px_per_second)
	if _playback.is_playing():
		_reveal_time(cursor_time, true)
	else:
		_set_scroll_offset(maxf(0.0, cursor_time * _px_per_second - playhead_screen_x))
		_reveal_time(cursor_time, false)
	_update_status()


func _set_scroll_offset(offset: float) -> void:
	var clamped := maxf(0.0, offset)
	_scroll.scroll_horizontal = clamped
	_timeline.set_scroll_x(clamped)


func _reveal_time(time_sec: float, follow_playback: bool) -> void:
	var view_w := maxf(1.0, _scroll.size.x)
	var clamped_time := maxf(0.0, time_sec)
	var time_x := clamped_time * _px_per_second
	var current_left := _scroll.scroll_horizontal
	var current_right := current_left + view_w
	var content_width := maxf(_timeline.custom_minimum_size.x, view_w)
	var max_offset := maxf(content_width - view_w, 0.0)

	var target_offset := NAN
	if follow_playback:
		target_offset = time_x - (view_w * PLAYBACK_TARGET_OFFSET_RATIO)
	elif time_x < current_left or time_x > current_right:
		target_offset = time_x - (view_w * MANUAL_REVEAL_CENTER_RATIO)

	if is_nan(target_offset):
		return

	var clamped_offset := clampf(target_offset, 0.0, max_offset)
	if absf(clamped_offset - current_left) <= SCROLL_UPDATE_THRESHOLD_PX:
		return

	_set_scroll_offset(clamped_offset)
	if follow_playback:
		EditorLog.info(
			"scroll",
			"left=%.1f right=%.1f x=%.1f target=%.1f follow=%s" % [
				current_left,
				current_right,
				time_x,
				clamped_offset,
				str(follow_playback)
			]
		)


func _setup_snap_options() -> void:
	_snap_option.clear()
	for d in GridSnapManager.SUPPORTED_DIVISIONS:
		_snap_option.add_item("1/%d" % d)
	_snap_option.item_selected.connect(func(idx: int) -> void:
		var text := _snap_option.get_item_text(idx)
		_grid.set_snap_string(text)
		_update_status()
	)
	_snap_option.select(2) # 1/4 default
	_grid.division = 4


func _apply_style() -> void:
	var palette := HDTheme.theme_palette("theme_neon")
	($Background as ColorRect).color = palette["background"]
	_top_panel.add_theme_stylebox_override("panel", HDTheme.overlay_panel_style())
	_reload_songs_button.add_theme_stylebox_override("normal", HDTheme.button_style(false))
	_reload_songs_button.add_theme_stylebox_override("hover", HDTheme.button_style(false))
	_reload_songs_button.add_theme_stylebox_override("pressed", HDTheme.button_style(false))
	_play_button.add_theme_stylebox_override("normal", HDTheme.button_style(true))
	_play_button.add_theme_stylebox_override("hover", HDTheme.button_style(true))
	_play_button.add_theme_stylebox_override("pressed", HDTheme.button_style(true))
	_save_button.add_theme_stylebox_override("normal", HDTheme.button_style(false))
	_save_button.add_theme_stylebox_override("hover", HDTheme.button_style(false))
	_save_button.add_theme_stylebox_override("pressed", HDTheme.button_style(false))
	_browse_audio_button.add_theme_stylebox_override("normal", HDTheme.button_style(false))
	_browse_audio_button.add_theme_stylebox_override("hover", HDTheme.button_style(false))
	_browse_audio_button.add_theme_stylebox_override("pressed", HDTheme.button_style(false))
	_auto_bpm_button.add_theme_stylebox_override("normal", HDTheme.button_style(false))
	_auto_bpm_button.add_theme_stylebox_override("hover", HDTheme.button_style(false))
	_auto_bpm_button.add_theme_stylebox_override("pressed", HDTheme.button_style(false))
	HDTheme.apply_label(_status_label, "caption", HDTheme.TERTIARY, false)


func _read_cmdline() -> void:
	for arg in OS.get_cmdline_args():
		if arg.begins_with("--editor_song_folder="):
			_song_folder = arg.split("=", true, 1)[1]
		elif arg.begins_with("--editor_difficulty="):
			_difficulty = arg.split("=", true, 1)[1].strip_edges().to_lower()
		elif arg.begins_with("--editor_chart_path="):
			_chart_path = arg.split("=", true, 1)[1]
		elif arg.begins_with("--editor_manifest_path="):
			_manifest_path = arg.split("=", true, 1)[1]


func _setup_song_picker() -> void:
	_reload_songs_button.pressed.connect(func() -> void:
		_reload_songs()
	)
	_song_option.item_selected.connect(func(_idx: int) -> void:
		_apply_selected_song_from_ui()
	)
	_difficulty_option.item_selected.connect(func(_idx: int) -> void:
		if _is_switching_song:
			return
		_difficulty = _difficulty_option.get_item_text(_difficulty_option.selected).strip_edges().to_lower()
		if not _song_folder.is_empty():
			_chart_path = SongResolver.get_chart_path(_song_folder, _difficulty)
		_load_session()
		_update_status()
	)


func _reload_songs() -> void:
	EditorLog.info("songs", "Reloading song database...")
	_song_db.reload()
	_song_entries = _song_db.get_songs()
	var load_errors: Array[Dictionary] = _song_db.get_load_errors()
	var load_warnings: Array[Dictionary] = _song_db.get_load_warnings()
	EditorLog.info("songs", "found=%d errors=%d warnings=%d" % [_song_entries.size(), load_errors.size(), load_warnings.size()])
	_song_option.clear()
	_difficulty_option.clear()

	if _song_entries.is_empty():
		_song_option.add_item("No songs found (add manifest.json under user://custom_songs/<folder>/)")
		_song_option.disabled = true
		_difficulty_option.disabled = true
		if not load_errors.is_empty():
			var first_err: Dictionary = load_errors[0]
			_chart_load_error = "Song load error: %s" % str(first_err.get("message", ""))
		elif not load_warnings.is_empty():
			var first_warn: Dictionary = load_warnings[0]
			_chart_load_error = "Song load warning: %s" % str(first_warn.get("message", ""))
		return

	_song_option.disabled = false
	_difficulty_option.disabled = false

	var pick_id := _selected_song_id
	if pick_id.is_empty() and not _song_folder.is_empty():
		# Resolve from folder path if possible.
		for entry in _song_entries:
			if str(entry.get("root_path", "")) == _song_folder:
				pick_id = str(entry.get("song_id", ""))
				break

	var selected_index := 0
	for i in range(_song_entries.size()):
		var e: Dictionary = _song_entries[i]
		var title := str(e.get("title", ""))
		var sid := str(e.get("song_id", ""))
		var source := str(e.get("source", ""))
		var label := "%s (%s)" % [title, source]
		_song_option.add_item(label)
		_song_option.set_item_metadata(i, sid)
		if not pick_id.is_empty() and sid == pick_id:
			selected_index = i

	_song_option.select(selected_index)
	_apply_selected_song_from_ui()


func _apply_selected_song_from_ui() -> void:
	if _song_entries.is_empty():
		return
	_is_switching_song = true
	var idx := _song_option.selected
	var song_id: String = str(_song_option.get_item_metadata(idx))
	_selected_song_id = song_id

	var entry: Dictionary = {}
	for e in _song_entries:
		if str(e.get("song_id", "")) == song_id:
			entry = e
			break
	if entry.is_empty():
		_is_switching_song = false
		return

	_song_folder = str(entry.get("root_path", ""))
	_manifest_path = str(entry.get("manifest_path", ""))
	EditorLog.info("songs", "selected song_id=%s folder=%s" % [_selected_song_id, _song_folder])

	var diffs: Array[String] = []
	for d in (entry.get("difficulties", []) as Array):
		if typeof(d) == TYPE_STRING:
			diffs.append(String(d))

	_difficulty_option.clear()
	if diffs.is_empty():
		diffs = ["expert"]
	for d2 in diffs:
		_difficulty_option.add_item(d2)

	var want := _difficulty.strip_edges().to_lower()
	var diff_idx := 0
	for j in range(diffs.size()):
		if diffs[j].to_lower() == want:
			diff_idx = j
			break
	_difficulty_option.select(diff_idx)
	_difficulty = _difficulty_option.get_item_text(diff_idx).strip_edges().to_lower()

	_chart_path = SongResolver.get_chart_path(_song_folder, _difficulty)
	_is_switching_song = false

	_load_session()
	_update_status()


func _load_session() -> void:
	_apply_default_zoom()
	if not _song_folder.is_empty():
		_manifest_path = SongResolver.get_manifest_path(_song_folder)
		_chart_path = SongResolver.get_chart_path(_song_folder, _difficulty)
		EditorLog.info("session", "song_folder=%s manifest=%s chart=%s" % [_song_folder, _manifest_path, _chart_path])
	if _chart_path.is_empty():
		_chart_path = "user://custom_songs/unsaved_%d_%s.json" % [Time.get_unix_time_from_system(), _difficulty]
		EditorLog.warn("session", "no chart path; defaulting to %s" % _chart_path)

	var bpm := 120.0
	var offset := 0.0
	var manifest: Dictionary = {}
	if FileAccess.file_exists(_manifest_path):
		var loaded: Dictionary = ChartLoader.load_json_dictionary(_manifest_path)
		if loaded.get("ok", false):
			manifest = loaded.get("value", {}) as Dictionary
			var mv: Dictionary = ChartValidator.validate_manifest(manifest)
			if ChartValidator.is_valid(mv):
				bpm = float(manifest.get("bpm", bpm))
				offset = float(manifest.get("offset", offset))
			else:
				EditorLog.warn("manifest", "invalid manifest at %s" % _manifest_path)
		else:
			EditorLog.err("manifest", "failed to parse %s: %s" % [_manifest_path, str(loaded.get("error", ""))])
	else:
		EditorLog.warn("manifest", "missing %s" % _manifest_path)

	_grid.bpm = bpm
	_grid.offset = offset
	EditorLog.info("grid", "bpm=%.3f offset=%.3f snap=%s" % [_grid.bpm, _grid.offset, _grid.get_snap_string()])
	_bpm_spin.value = _grid.bpm

	var chart_notes: Array[Dictionary] = []
	_chart_load_error = ""
	if FileAccess.file_exists(_chart_path):
		var result: Dictionary = ChartLoader.load_hd_chart(_chart_path, _difficulty)
		if result.get("ok", false):
			var chart: Dictionary = result.get("chart", {}) as Dictionary
			for n in (chart.get("notes", []) as Array):
				if n is Dictionary:
					chart_notes.append(n as Dictionary)
		else:
			var errs: Array = result.get("errors", []) as Array
			if not errs.is_empty():
				var first: Dictionary = errs[0] as Dictionary
				_chart_load_error = str(first.get("message", "Chart parse error"))
				EditorLog.err("chart", "load failed: %s (%s)" % [_chart_load_error, _chart_path])
			else:
				EditorLog.err("chart", "load failed with unknown error (%s)" % _chart_path)
	else:
		EditorLog.warn("chart", "missing %s (starting empty)" % _chart_path)
	_notes.set_notes(chart_notes)

	var audio_res: Dictionary
	if not _selected_audio_path.is_empty():
		if FileAccess.file_exists(_selected_audio_path):
			audio_res = {"status": "available", "path": _selected_audio_path, "reason": "Selected audio override."}
		else:
			_selected_audio_path = ""
			audio_res = AudioResolver.resolve_audio(manifest, _song_folder)
	else:
		audio_res = AudioResolver.resolve_audio(manifest, _song_folder)
	_audio_reason = str(audio_res.get("reason", ""))
	if audio_res.get("status", "") == "available":
		var audio_path: String = str(audio_res.get("path", ""))
		var stream := _load_audio_stream(audio_path)
		_playback.set_stream(stream)
		_waveform.prepare_from_stream(stream)
		EditorLog.info("audio", "using %s" % audio_path)
	else:
		_waveform.prepare_from_stream(null)
		EditorLog.warn("audio", "no audio available: %s" % _audio_reason)

	_rebuild_audio_options(manifest)
	if _playback.has_audio():
		# Attempt auto BPM once when audio becomes available.
		_auto_detect_bpm(false)

	_timeline.set_audio_length(_playback.length_sec())
	_timeline.set_notes(_notes.get_notes())
	_timeline.set_cursor_time(_playback.get_position())


func _load_audio_stream(path: String) -> AudioStream:
	if path.is_empty():
		return null
	if path.begins_with("res://"):
		var res: Resource = ResourceLoader.load(path)
		return res as AudioStream

	# user:// runtime load
	if path.ends_with(".wav"):
		return AudioStreamWAV.load_from_file(ProjectSettings.globalize_path(path))
	if path.ends_with(".ogg"):
		return AudioStreamOggVorbis.load_from_file(ProjectSettings.globalize_path(path))
	if path.ends_with(".mp3"):
		return AudioStreamMP3.load_from_file(ProjectSettings.globalize_path(path))
	return null


func save_chart() -> void:
	var payload := {
		"version": 1,
		"difficulty": _difficulty,
		"notes": _notes.get_notes(),
	}
	var validation: Dictionary = ChartValidator.validate_chart(payload, _difficulty)
	if not ChartValidator.is_valid(validation):
		var errs: Array = validation.get("errors", []) as Array
		var first: Dictionary = errs[0] as Dictionary if not errs.is_empty() else {}
		_status_label.text = "Save blocked: %s" % str(first.get("message", "invalid chart"))
		return

	var json := JSON.stringify(payload, "\t", false)
	if _chart_path.begins_with("res://"):
		_status_label.text = "Save blocked: cannot write to res:// in exports. Use user://."
		return
	SongResolver.ensure_user_song_dirs()
	var target_path := _chart_path
	var abs := _chart_path
	if _chart_path.begins_with("user://"):
		abs = ProjectSettings.globalize_path(_chart_path)
	else:
		target_path = abs
	DirAccess.make_dir_recursive_absolute(abs.get_base_dir())
	var f := FileAccess.open(target_path, FileAccess.WRITE)
	if f == null:
		_status_label.text = "Save failed: %s" % _chart_path
		return
	f.store_string(json)
	f.flush()
	_status_label.text = "Saved: %s" % _chart_path


func _update_status() -> void:
	var pos := _playback.get_position()
	var snap := _grid.get_snap_string()
	var zoom := int(roundf(_px_per_second))
	var mode := "HOLD" if _notes.hold_mode else "TAP"
	var audio := "audio" if _playback.has_audio() else "no-audio"
	if audio == "no-audio" and not _audio_reason.is_empty():
		audio = "no-audio (%s)" % _audio_reason
	var base := "t=%.3f  snap=%s  zoom=%dpx/s  mode=%s  %s  notes=%d" % [pos, snap, zoom, mode, audio, _notes.get_notes().size()]
	if not _chart_load_error.is_empty():
		base = "Chart load error: %s  |  %s" % [_chart_load_error, base]
	_status_label.text = base


func _rebuild_audio_options(manifest: Dictionary) -> void:
	_audio_option.clear()
	_audio_option.add_item("Audio: Auto")
	_audio_option.set_item_metadata(0, "")

	var song_id := str(manifest.get("song_id", ""))
	var entries: Array[Dictionary] = []
	for e in AudioResolver.list_folder_audio(_song_folder):
		entries.append(e as Dictionary)
	for c in AudioResolver.list_cached_audio(song_id):
		entries.append(c as Dictionary)

	var idx := 1
	for entry in entries:
		var p := str(entry.get("path", ""))
		if p.is_empty():
			continue
		var label := "Audio: %s" % p.get_file()
		_audio_option.add_item(label)
		_audio_option.set_item_metadata(idx, p)
		idx += 1

	var select_idx := 0
	if not _selected_audio_path.is_empty():
		for i in range(_audio_option.item_count):
			if str(_audio_option.get_item_metadata(i)) == _selected_audio_path:
				select_idx = i
				break
	_audio_option.select(select_idx)


func _on_audio_option_selected() -> void:
	var p := str(_audio_option.get_item_metadata(_audio_option.selected))
	_selected_audio_path = p
	EditorLog.info("audio", "selected audio option: %s" % (_selected_audio_path if not _selected_audio_path.is_empty() else "auto"))
	_load_session()
	_update_status()


func _on_audio_file_selected(path: String) -> void:
	if path.is_empty():
		return
	if _selected_song_id.is_empty():
		EditorLog.warn("audio", "browse selected but no song is selected")
		return

	var ext := "." + path.get_extension().to_lower()
	var target_user_path := AudioResolver.cache_path_for_song_id(_selected_song_id, ext)
	if target_user_path.is_empty():
		EditorLog.err("audio", "failed to derive cache path for song_id=%s" % _selected_song_id)
		return

	SongResolver.ensure_user_song_dirs()
	var bytes := FileAccess.get_file_as_bytes(path)
	if bytes.is_empty():
		EditorLog.err("audio", "failed to read selected file: %s" % path)
		return

	var f := FileAccess.open(target_user_path, FileAccess.WRITE)
	if f == null:
		EditorLog.err("audio", "failed to write cache file: %s" % target_user_path)
		return
	f.store_buffer(bytes)
	f.flush()

	_selected_audio_path = target_user_path
	EditorLog.info("audio", "cached selected audio to %s" % target_user_path)
	_load_session()
	_update_status()


func _auto_detect_bpm(log_failure: bool = true) -> void:
	if _analysis_in_progress:
		if log_failure:
			EditorLog.warn("bpm", "Auto BPM already running.")
		return
	var stream := _audio_player.stream
	if stream == null:
		if log_failure:
			EditorLog.warn("bpm", "No audio loaded.")
		return

	# Fast/offline path for WAV.
	var wav_result: Dictionary = BPMDetector.detect_bpm_from_stream(stream)
	if bool(wav_result.get("ok", false)):
		_apply_bpm_result(wav_result)
		return

	# Realtime capture path for compressed formats (OGG/MP3).
	_analysis_in_progress = true
	EditorLog.info("bpm", "Auto BPM (realtime) started...")
	call_deferred("_auto_detect_bpm_realtime")


func _apply_bpm_result(result: Dictionary) -> void:
	var bpm := float(result.get("bpm", _grid.bpm))
	var conf := float(result.get("confidence", 0.0))
	_grid.bpm = bpm
	_bpm_spin.value = bpm
	EditorLog.info("bpm", "auto bpm=%.3f confidence=%.2f" % [bpm, conf])
	_update_status()


func _ensure_analysis_bus() -> void:
	_analysis_bus_idx = AudioServer.get_bus_index(ANALYSIS_BUS_NAME)
	if _analysis_bus_idx < 0:
		AudioServer.add_bus(-1)
		_analysis_bus_idx = AudioServer.get_bus_count() - 1
		AudioServer.set_bus_name(_analysis_bus_idx, ANALYSIS_BUS_NAME)
		AudioServer.set_bus_send(_analysis_bus_idx, &"Master")
		EditorLog.info("audio", "Created analysis bus '%s'" % String(ANALYSIS_BUS_NAME))

	# Ensure capture effect exists.
	var capture: AudioEffectCapture = null
	var effect_count: int = AudioServer.get_bus_effect_count(_analysis_bus_idx)
	for i in range(effect_count):
		var eff: AudioEffect = AudioServer.get_bus_effect(_analysis_bus_idx, i)
		if eff is AudioEffectCapture:
			capture = eff as AudioEffectCapture
			break
	if capture == null:
		capture = AudioEffectCapture.new()
		capture.buffer_length = 2.0
		AudioServer.add_bus_effect(_analysis_bus_idx, capture, 0)
		EditorLog.info("audio", "Added capture effect to analysis bus")
	_analysis_capture = capture


func _auto_detect_bpm_realtime() -> void:
	# Capture ~16 seconds of decoded audio from the analysis bus.
	if _analysis_bus_idx < 0 or _analysis_capture == null:
		EditorLog.warn("bpm", "Analysis bus not available.")
		_analysis_in_progress = false
		return

	var prev_bus: StringName = _audio_player.bus
	var prev_playing := _playback.is_playing()
	var prev_pos := _playback.get_position()

	# Mute analysis bus while capturing, to avoid blasting the user.
	var prev_db := AudioServer.get_bus_volume_db(_analysis_bus_idx)
	AudioServer.set_bus_volume_db(_analysis_bus_idx, -80.0)

	_analysis_capture.clear_buffer()
	_audio_player.bus = ANALYSIS_BUS_NAME

	_playback.pause()
	_playback.seek(0.0)
	_playback.play()

	var mix_rate := float(AudioServer.get_mix_rate())
	var envelope_rate := 200.0
	var hop := int(maxf(1.0, mix_rate / envelope_rate))

	var target_seconds := 16.0
	var target_env_len := int(target_seconds * envelope_rate)
	var env: PackedFloat32Array = PackedFloat32Array()
	env.resize(0)

	var frame_accum := 0
	var amp_accum := 0.0

	while env.size() < target_env_len:
		await get_tree().create_timer(0.05).timeout
		var available := _analysis_capture.get_frames_available()
		if available <= 0:
			continue
		var frames := mini(available, int(mix_rate * 0.25))
		var buf: PackedVector2Array = _analysis_capture.get_buffer(frames)
		if buf.is_empty():
			continue
		for v in buf:
			var mono := (absf(v.x) + absf(v.y)) * 0.5
			amp_accum += mono
			frame_accum += 1
			if frame_accum >= hop:
				env.append(amp_accum / float(frame_accum))
				amp_accum = 0.0
				frame_accum = 0
				if env.size() >= target_env_len:
					break

	_playback.pause()

	# Restore routing/volume/state.
	_audio_player.bus = prev_bus
	AudioServer.set_bus_volume_db(_analysis_bus_idx, prev_db)
	_playback.seek(prev_pos)
	if prev_playing:
		_playback.play()

	var result: Dictionary = BPMDetector.detect_bpm_from_envelope(env, envelope_rate)
	if not bool(result.get("ok", false)):
		EditorLog.warn("bpm", str(result.get("reason", "Auto BPM failed.")))
		_analysis_in_progress = false
		return
	_apply_bpm_result(result)
	_analysis_in_progress = false
